import pandas as pd
import numpy as np
import time
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import SMOTE

def main():
    file_path = "C:\\Users\\HP\\Downloads\\Lab Session Data.xlsx"
    df = pd.read_excel(file_path, sheet_name="thyroid0387_UCI")


    df.drop(columns=['Record ID'], inplace=True)

    
    categorical_cols = df.select_dtypes(include=['object']).columns
    df[categorical_cols] = df[categorical_cols].astype(str)

   
    df[categorical_cols] = df[categorical_cols].apply(LabelEncoder().fit_transform)

    
    target_column = 'Condition'
    X = df.drop(columns=[target_column])
    y = df[target_column]

    
    class_counts = y.value_counts()
    rare_classes = class_counts[class_counts <= 1].index
    df = df[~df[target_column].isin(rare_classes)]  

    
    X = df.drop(columns=[target_column])
    y = df[target_column]

    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    
    min_class_size = y_train.value_counts().min()
    k_neighbors = min(3, min_class_size - 1) if min_class_size > 1 else 1  
    smote = SMOTE(sampling_strategy="auto", k_neighbors=k_neighbors, random_state=42)

    X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)

   
    param_grid = {'n_neighbors': range(1, 30)}

    
    print("\n Running GridSearchCV...")
    start_time = time.time()

    grid_search = GridSearchCV(KNeighborsClassifier(), param_grid, cv=5, n_jobs=-1)
    grid_search.fit(X_train_resampled, y_train_resampled)

    end_time = time.time()
    best_k_grid = grid_search.best_params_['n_neighbors']
    print(f" Best k (GridSearchCV): {best_k_grid}")
    print(f" GridSearchCV completed in {end_time - start_time:.2f} seconds")

    
    print("\n Running RandomizedSearchCV...")
    start_time = time.time()

    random_search = RandomizedSearchCV(KNeighborsClassifier(), param_distributions=param_grid, n_iter=10, cv=5, random_state=42, n_jobs=-1)
    random_search.fit(X_train_resampled, y_train_resampled)

    end_time = time.time()
    best_k_random = random_search.best_params_['n_neighbors']
    print(f" Best k (RandomizedSearchCV): {best_k_random}")
    print(f" RandomizedSearchCV completed in {end_time - start_time:.2f} seconds")


if __name__ == "__main__":
    main()
