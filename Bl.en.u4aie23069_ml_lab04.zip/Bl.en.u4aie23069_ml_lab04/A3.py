import numpy as np
import matplotlib.pyplot as plt


np.random.seed(42)
X = np.random.uniform(1, 10, 20)
Y = np.random.uniform(1, 10, 20)


labels = (X + Y > 10).astype(int)  


colors = ['blue' if label == 0 else 'red' for label in labels]
plt.scatter(X, Y, c=colors, label="Training Data")

plt.xlabel("Feature X")
plt.ylabel("Feature Y")
plt.title("Scatter Plot of Training Data")
plt.show()
