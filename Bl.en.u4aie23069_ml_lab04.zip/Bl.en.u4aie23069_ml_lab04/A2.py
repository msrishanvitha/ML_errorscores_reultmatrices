import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score

file_path = "C:\\Users\\HP\\Downloads\\Lab Session Data.xlsx"
df = pd.read_excel(file_path, sheet_name="IRCTC Stock Price")


for col in df.columns:
    if df[col].dtype == 'object':  
        try:
            df[col] = pd.to_datetime(df[col], format="%b %d, %Y", errors='coerce')  
            df[col] = df[col].astype(int) // 10**9  
        except Exception as e:
            print(f"Skipping column {col} due to error: {e}")


df = df.dropna()


X = df.iloc[:, :-1]
y = df.iloc[:, -1]


X = X.apply(pd.to_numeric, errors='coerce')
X = X.dropna()  
y = y[X.index]  


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


model = LinearRegression()
model.fit(X_train, y_train)


y_pred = model.predict(X_test)


mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mape = mean_absolute_percentage_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"MSE: {mse:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"MAPE: {mape:.4f}")
print(f"R² Score: {r2:.4f}")
