import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier


np.random.seed(42)
X_train = np.random.uniform(1, 10, (20, 2))
y_train = (X_train[:, 0] + X_train[:, 1] > 10).astype(int)


x_test = np.arange(0, 10.1, 0.1)
y_test = np.arange(0, 10.1, 0.1)
X_test = np.array(np.meshgrid(x_test, y_test)).T.reshape(-1, 2)


k_values = [1, 3, 5, 7]
fig, axes = plt.subplots(2, 2, figsize=(10, 10))

for i, k in enumerate(k_values):
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)

    colors = ['blue' if label == 0 else 'red' for label in y_pred]
    ax = axes[i // 2, i % 2]
    ax.scatter(X_test[:, 0], X_test[:, 1], c=colors, s=1)
    ax.set_title(f"k-NN Classification (k={k})")

plt.show()
