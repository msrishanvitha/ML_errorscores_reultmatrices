import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import SMOTE
import matplotlib.pyplot as plt


file_path = "C:\\Users\\HP\\Downloads\\Lab Session Data.xlsx"
df = pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

df.drop(columns=['Record ID'], inplace=True)


categorical_cols = df.select_dtypes(include=['object']).columns
df[categorical_cols] = df[categorical_cols].astype(str)


df[categorical_cols] = df[categorical_cols].apply(LabelEncoder().fit_transform)


target_column = 'Condition'
X = df.drop(columns=[target_column])
y = df[target_column]


class_counts = y.value_counts()
df = df[df[target_column].map(class_counts) > 1]
X = df.drop(columns=[target_column])
y = df[target_column]


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)


min_class_size = y_train.value_counts().min()


smote = SMOTE(sampling_strategy="auto", k_neighbors=min(3, min_class_size - 1), random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)


knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train_resampled, y_train_resampled)


y_pred = knn.predict(X_test)


print("k-NN Classification Completed.")


print("\nClass Distribution Before SMOTE:")
print(y_train.value_counts())

print("\nClass Distribution After SMOTE:")
print(pd.Series(y_train_resampled).value_counts())
