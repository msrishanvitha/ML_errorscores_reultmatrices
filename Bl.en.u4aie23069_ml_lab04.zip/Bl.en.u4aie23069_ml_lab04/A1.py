import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score


file_path = "C:\\Users\\HP\\Downloads\\Lab Session Data.xlsx"
sheet_name = "thyroid0387_UCI" 

df = pd.read_excel(file_path, sheet_name=sheet_name)


categorical_cols = df.select_dtypes(include=['object']).columns
df[categorical_cols] = df[categorical_cols].astype(str)


df[categorical_cols] = df[categorical_cols].apply(LabelEncoder().fit_transform)


df.dropna(subset=[df.columns[-1]], inplace=True)


X = df.iloc[:, :-1]  
y = df.iloc[:, -1]   


class_counts = y.value_counts()
valid_classes = class_counts[class_counts > 1].index
df = df[df.iloc[:, -1].isin(valid_classes)]


X = df.iloc[:, :-1]
y = df.iloc[:, -1]


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)


y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)


cm_test = confusion_matrix(y_test, y_test_pred)


precision = precision_score(y_test, y_test_pred, average='weighted', zero_division=0)
recall = recall_score(y_test, y_test_pred, average='weighted')
f1 = f1_score(y_test, y_test_pred, average='weighted')


print(f"Confusion Matrix:\n{cm_test}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1 Score: {f1:.4f}")

train_f1 = f1_score(y_train, y_train_pred, average='weighted')
test_f1 = f1_score(y_test, y_test_pred, average='weighted')

if train_f1 > test_f1 + 0.05:
    print("Model Outcome: Good Fit (Balanced performance on training and test)")
elif train_f1 < test_f1 - 0.05:
    print("Model Outcome: Underfitting (Poor performance on both training and test)")
else:
    print("Model Outcome: Overfitting (High performance on training, lower on test)")
     
